package com.shibeta.unit4.day03.Assignment.SaveInClass;

/**
 * @author Shibeta
 */
public class Student {
    /**
     * 设置属性name、age、classNum
     */
    private String name;
    private int age;
    private String classNum;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getClassNum() {
        return classNum;
    }

    public void setClassNum(String classNum) {
        this.classNum = classNum;
    }
}
