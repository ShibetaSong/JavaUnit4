package com.shibeta.unit4.day05.HW.View;

public class ExceptionMessage {
    public static String wrongSelect() {
        return "选择有误";
    }

    public static String wrongInput() {
        return "输入有误";
    }

}
